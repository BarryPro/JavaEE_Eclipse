#define REDIS_GIT_SHA1 "e4a3d7ff"
#define REDIS_GIT_DIRTY "       0"
