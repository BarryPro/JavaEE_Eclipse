#define REDIS_GIT_SHA1 "556bdfba"
#define REDIS_GIT_DIRTY "     629"
