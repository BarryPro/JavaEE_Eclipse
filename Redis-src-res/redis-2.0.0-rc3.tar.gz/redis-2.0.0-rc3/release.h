#define REDIS_GIT_SHA1 "fe2173ae"
#define REDIS_GIT_DIRTY "      48"
