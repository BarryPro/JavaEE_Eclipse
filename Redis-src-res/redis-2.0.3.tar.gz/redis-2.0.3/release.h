#define REDIS_GIT_SHA1 "b766149d"
#define REDIS_GIT_DIRTY "       0"
