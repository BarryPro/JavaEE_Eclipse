#define REDIS_GIT_SHA1 "068eb3bf"
#define REDIS_GIT_DIRTY "       0"
